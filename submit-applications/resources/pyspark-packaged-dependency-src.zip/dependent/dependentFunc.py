def message():
  print("Printing from inside the dependent python file")

